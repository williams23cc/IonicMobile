app.controller('mostrar_tabla_controller', ['$scope', 'factoryPlaca', 'resolveData', 
	function($scope, factoryPlaca, resolveData){
		$scope.datos={
			lista: [],
			mensaje: ''
		};					
					resolveData.getRuta().
					success(function(data, status, headers, config) {
						if(data.length>0){
							//alert(data.length);
							$scope.datos.lista=data;}
						else
							$scope.datos.mensaje = "No tiene papeleta";
					}).error(function(data, status, headers, config) {
						$scope.datos.mensaje = "Problemas de conexion";
					});
}]);

app.controller('HomeCtrl', ['$scope', '$location','resolveData','factoryPlaca', function($scope, $location,resolveData,factoryPlaca){
	
	$scope.datos = {
		placa : '',
		mensaje : ''
	} ;
	$scope.uppercase_placa = function (){
		$scope.datos.placa = $scope.datos.placa.toUpperCase(); 
	};
	$scope.verificar_acceso = function (){
		if($scope.datos.placa!='')
		{
			factoryPlaca.set_placa($scope.datos.placa);
			
			resolveData.getRuta().
			success(function(data, status, headers, config) {
				if(data.length>0){
					//alert('tabla controller');
					$scope.datos.placa = "";
					$scope.datos.mensaje = "";
					$location.url(resolveData.url);}
				else
					$scope.datos.mensaje = "Placa Invalida!";
			}).error(function(data, status, headers, config) {
				$scope.datos.mensaje = "Problemas de conexion";
			});
		}
		else
			$scope.datos.mensaje = "Campo Vacio";
		//$location.url('/tab/consul_papeleta');
	}
}]);