app.controller('mostrar_lista_controller', ['$scope', '$location', 'resolveData', 'factoryPlaca',
	function($scope, $location, resolveData, factoryPlaca){
		$scope.datos={
				buscar: '',
				original: [],
				lista:[],
				Tablahash: {'Grave':'img/icontexto-message-types-alert-orange.png', 'Leve':'img/icontexto-message-types-alert-blue.png', 'Muy Grave':'img/icontexto-message-types-alert-red.png'}
		};
	
		resolveData.getRuta().success(function(data, status, headers, config){
			//alert('data -> '+ data.length);
			//alert('datos.lista -> '+ $scope.datos.lista.length);
			$scope.datos.lista = data;
			$scope.datos.original = data;
			/*for(var i=0;i<$scope.datos.lista.length;i++) {
				if($scope.datos.lista[i]['gravedad'] == 'Grave')
					$scope.datos.imagen.push("img/icontexto-message-types-alert-orange.png");
					
					/*$scope.datos.imagen = "img/icontexto-message-types-alert-orange.png";
				if($scope.datos.lista[i]['gravedad'] == 'Leve')
					$scope.datos.imagen = "img/icontexto-message-types-alert-blue.png";
			}*/
		}).error(function(){
			alert('EE');
		});
		
		$scope.funcion=function(_objeto){
			factoryPlaca.set_objeto(_objeto);
			$location.url(resolveData.getUrl());
		};
		
		$scope.fuzzy=function(tipo){
			if($scope.datos.buscar=='') {
	    		$scope.datos.lista = $scope.datos.original;
	    		return;
	    	}

	    	$scope.datos.lista=[];
	    	for(var i=0;i<$scope.datos.original.length; ++i){
	    		
	    		if($scope.verificar($scope.datos.original[i][tipo].toLowerCase(),$scope.datos.buscar.toLowerCase()))
	    			$scope.datos.lista.push($scope.datos.original[i]);  		
	    	}
		};
		
		$scope.verificar = function(frase,busca){
			var array_busca=busca.split(" ");
			var array_frase=frase.split(" ");
			for(var i=0;i<array_frase.length;++i)
			{
				for(var j=0;j<array_busca.length;++j){
					if($scope.subfuzzy(array_frase[i],array_busca[j])) return true;
				}
			}
			return false;
	  	};
	  	$scope.subfuzzy=  function(pal_o,pal_b){
			var  tam_o=pal_o.length;
			var  tam_b=pal_b.length;
			if(tam_b>tam_o) return false;
			
			for(var i=0,ini_o=0;i<tam_b;++i){
	  			while(ini_o < tam_o && pal_o[ini_o]!=pal_b[i]) ++ini_o;
				if(++ini_o > tam_o) return false;
	  		}
	  		return true;
		}
	  	
	}
]);