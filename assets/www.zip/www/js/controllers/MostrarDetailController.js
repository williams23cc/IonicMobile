app.controller('mostrar_detail_controller', ['$scope', '$location', '$stateParams', 'resolveData', 'factoryPlaca',
	function($scope, $location, $stateParams, resolveData, factoryPlaca){
		//alert(factoryPlaca.get_objeto());
		$scope.detail_lista = factoryPlaca.get_objeto();
		
		

		
		/*$scope.datos={
			detail_lista = resolveData.getDetail('00123');			
		};
		$scope.funcion=function(_objeto){
			factoryPlaca.set_objeto(_objeto);
			$location.url('tab/lista_detail_permisos');
		}
		
		//$scope.datos.lista = factoryPlaca.get_lista();
		//var detalle_lista = resolveData.getDetail('00123');
		
		$scope.detail_lista = resolveData.getDetail('00123');*/	
//		alert($scope.detail_lista);
		//alert($scope.datos.lista.length);
		//alert(detalle_lista.length);
	}
]);
