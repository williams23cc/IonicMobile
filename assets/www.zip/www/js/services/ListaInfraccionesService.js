app.service("lista_infracciones_service", function($http){
	this.getRuta = function(){
		//var ruta = 'js/json/lista_infracciones.json';
		var ruta = 'http://diegografico.webuda.com/json/infraccion.php';
		return $http.get(ruta);
	}
	this.getUrl = function(){
		var url = 'tab/lista_detail_infracciones';
		return url;
	}
});