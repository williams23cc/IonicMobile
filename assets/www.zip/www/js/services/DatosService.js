/*app.service("datos_service", function($http){
	this.getRuta = function(){
		var ruta = 'http://diegografico.webuda.com/json/datos.php?placa=ABC123';
		return $http.get(ruta);
	}
});*/

app.service("datos_service",['$http','factoryPlaca', function($http,factoryPlaca){
	this.url = "tab/lista_papeletas";
	this.getRuta = function(){
		var ruta="http://diegografico.webuda.com/json/datos.php?placa="+factoryPlaca.get_placa();
		//var ruta = 'resources/json/DH2836_2.json';
		return $http.get(ruta);
	}
	
}]);