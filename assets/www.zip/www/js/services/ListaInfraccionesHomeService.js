app.service("lista_infracciones_home_service", function($http){
	this.getRuta = function(){
		var ruta = 'http://diegografico.webuda.com/json/infraccion.php';
		return $http.get(ruta);
	}
	this.getUrl = function(){
		var url = 'tab2/lista_detail_infracciones';
		return url;
	}
});