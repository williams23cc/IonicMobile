app.service('lista_permisos_service', ['$http', 'factoryPlaca',
	function($http, factoryPlaca){
		this.getRuta = function(){
			var ruta='http://diegografico.webuda.com/json/permiso.php?placa='+factoryPlaca.get_placa();
			return $http.get(ruta);
		}
		
		//var all_lista = factoryPlaca.get_lista();

		/*this.getDetail = function(num_permiso){
			var all_lista = factoryPlaca.get_lista();
			//alert('entro al servicio');
			//alert(all_lista);
			for (var i = 0; i < all_lista.length; i++) {
				if (all_lista[i].numero_autorizacion === parseInt(num_permiso)) {
					return all_lista[i];
		         }
			}
			//alert(all_lista);
		    return null;
		}*/
		
		this.getUrl = function(){
			var url = 'tab/lista_detail_permisos';
			return url;
		}
	}
]);